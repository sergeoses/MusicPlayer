package com.app.musicplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.SearchView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var btnPlayPause: ImageButton
    private lateinit var btnNext: ImageButton
    private lateinit var btnPrev: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var btnSpeed: Button
    private lateinit var btnFilterFav: Button
    private lateinit var seekBar: SeekBar
    private lateinit var tvCurrentSong: TextView
    private lateinit var tvCurrentTime: TextView
    private lateinit var tvTotalTime: TextView
    private lateinit var tvSongCount: TextView
    private lateinit var searchView: SearchView

    private lateinit var adapter: SongsAdapter
    private val allSongsList = mutableListOf<Song>()
    private var displaySongsList = mutableListOf<Song>()

    private var mediaPlayer: MediaPlayer? = null
    private var currentSongIndex = -1
    private var isShuffle = false
    private var isRepeat = false
    private var isFavFilterOn = false

    private val speeds = listOf(1.0f, 1.25f, 1.5f, 2.0f, 0.5f)
    private var currentSpeedIndex = 0

    private val handler = Handler(Looper.getMainLooper())

    private val deleteLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            Toast.makeText(this, "Видалено", Toast.LENGTH_SHORT).show()
            loadSongs()
        }
    }

    private val updateSeekBar = object : Runnable {
        override fun run() {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    seekBar.progress = it.currentPosition
                    tvCurrentTime.text = formatTime(it.currentPosition)
                }
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initViews()
        setupListeners()
        checkPermissions()
    }

    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        btnPlayPause = findViewById(R.id.btnPlayPause)
        btnNext = findViewById(R.id.btnNext)
        btnPrev = findViewById(R.id.btnPrev)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnSpeed = findViewById(R.id.btnSpeed)
        btnFilterFav = findViewById(R.id.btnFilterFav)
        seekBar = findViewById(R.id.seekBar)
        tvCurrentSong = findViewById(R.id.tvCurrentSong)
        tvCurrentSong.isSelected = true
        tvCurrentTime = findViewById(R.id.tvCurrentTime)
        tvTotalTime = findViewById(R.id.tvTotalTime)
        tvSongCount = findViewById(R.id.tvSongCount)
        searchView = findViewById(R.id.searchView)
    }

    private fun setupListeners() {
        btnPlayPause.setOnClickListener { togglePlayPause() }
        btnNext.setOnClickListener { playNext() }
        btnPrev.setOnClickListener { playPrev() }

        btnShuffle.setOnClickListener {
            isShuffle = !isShuffle
            val color = if (isShuffle) "#E94560" else "#8D93AB"
            btnShuffle.setColorFilter(Color.parseColor(color))
            Toast.makeText(this, if (isShuffle) "Shuffle ON" else "Shuffle OFF", Toast.LENGTH_SHORT).show()
        }

        btnRepeat.setOnClickListener {
            isRepeat = !isRepeat
            val color = if (isRepeat) "#E94560" else "#8D93AB"
            btnRepeat.setColorFilter(Color.parseColor(color))
            Toast.makeText(this, if (isRepeat) "Repeat ON 🔁" else "Repeat OFF", Toast.LENGTH_SHORT).show()
        }

        btnSpeed.setOnClickListener {
            currentSpeedIndex = (currentSpeedIndex + 1) % speeds.size
            val speed = speeds[currentSpeedIndex]
            btnSpeed.text = "${speed}x"
            btnSpeed.setTextColor(if (speed == 1.0f) Color.parseColor("#B0B0B0") else Color.parseColor("#E94560"))
            if (Build.VERSION.SDK_INT >= 23 && mediaPlayer != null) {
                try { mediaPlayer?.playbackParams = mediaPlayer!!.playbackParams.setSpeed(speed) } catch (e: Exception) {}
            }
        }

        btnFilterFav.setOnClickListener {
            isFavFilterOn = !isFavFilterOn
            btnFilterFav.setTextColor(if (isFavFilterOn) Color.parseColor("#E94560") else Color.parseColor("#8D93AB"))
            applyFilter(searchView.query.toString())
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    mediaPlayer?.seekTo(progress)
                    tvCurrentTime.text = formatTime(progress)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                applyFilter(newText)
                return true
            }
        })
    }

    private fun checkPermissions() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadSongs()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(permission), 100)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) loadSongs()
    }

    private fun loadSongs() {
        allSongsList.clear()
        val prefs = getSharedPreferences("MusicPrefs", Context.MODE_PRIVATE)
        val favSet = prefs.getStringSet("favorites", emptySet()) ?: emptySet()

        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DATA)
        try {
            val cursor = contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, null)
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(0)
                    val title = cursor.getString(1)
                    val artist = cursor.getString(2) ?: "Unknown"
                    val path = cursor.getString(3)
                    if (path != null && File(path).exists()) {
                        val isFav = favSet.contains(id.toString())
                        allSongsList.add(Song(id, title, artist, path, isFav))
                    }
                }
                cursor.close()
            }
        } catch (e: Exception) {}

        applyFilter("")

        adapter = SongsAdapter(displaySongsList,
            onSongClick = { song ->
                currentSongIndex = allSongsList.indexOf(song)
                playMusic(song)
            },
            onSongLongClick = { song -> showOptionsDialog(song) }
        )
        recyclerView.adapter = adapter
    }

    private fun applyFilter(query: String?) {
        val q = query ?: ""
        val step1 = if (isFavFilterOn) allSongsList.filter { it.isFavorite } else allSongsList
        val step2 = if (q.isNotEmpty()) step1.filter { it.title.contains(q, true) || it.artist.contains(q, true) } else step1
        displaySongsList = ArrayList(step2)
        if (::adapter.isInitialized) adapter.updateList(displaySongsList)
        tvSongCount.text = "${displaySongsList.size} пісень"
    }

    private fun showOptionsDialog(song: Song) {
        val options = arrayOf(if(song.isFavorite) "Прибрати з улюблених" else "В улюблені ❤", "Поділитися", "Видалити")
        AlertDialog.Builder(this)
            .setTitle(song.title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> toggleFavorite(song)
                    1 -> shareSong(song)
                    2 -> deleteSong(song)
                }
            }
            .show()
    }

    private fun toggleFavorite(song: Song) {
        song.isFavorite = !song.isFavorite
        val prefs = getSharedPreferences("MusicPrefs", Context.MODE_PRIVATE)
        val favSet = prefs.getStringSet("favorites", mutableSetOf())!!.toMutableSet()
        if (song.isFavorite) favSet.add(song.id.toString()) else favSet.remove(song.id.toString())
        prefs.edit().putStringSet("favorites", favSet).apply()
        applyFilter(searchView.query.toString())
    }

    private fun shareSong(song: Song) {
        try {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "audio/*"
            shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.parse(song.path))
            startActivity(Intent.createChooser(shareIntent, "Поділитися..."))
        } catch (e: Exception) {}
    }

    private fun deleteSong(song: Song) {
        try {
            val file = File(song.path)
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.Q) {
                if (file.delete()) { loadSongs() }
                else { contentResolver.delete(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id), null, null); loadSongs() }
            } else {
                val uriList = listOf(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id))
                val pendingIntent = MediaStore.createDeleteRequest(contentResolver, uriList)
                val intentSenderRequest = IntentSenderRequest.Builder(pendingIntent.intentSender).build()
                deleteLauncher.launch(intentSenderRequest)
            }
        } catch (e: Exception) {}
    }

    private fun playMusic(song: Song) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(song.path)
                prepare()
                if (Build.VERSION.SDK_INT >= 23 && speeds[currentSpeedIndex] != 1.0f) {
                    playbackParams = playbackParams.setSpeed(speeds[currentSpeedIndex])
                }
                start()
                setOnCompletionListener {
                    if (isRepeat) playMusic(song) else playNext()
                }
            }
            tvCurrentSong.text = "${song.title} - ${song.artist}"
            seekBar.max = mediaPlayer!!.duration
            tvTotalTime.text = formatTime(mediaPlayer!!.duration)

            btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)

            adapter.selectedPosition = allSongsList.indexOf(song)
            adapter.notifyDataSetChanged()
            handler.post(updateSeekBar)
        } catch (e: Exception) {}
    }

    private fun togglePlayPause() {
        mediaPlayer?.let {
            if (it.isPlaying) {
                it.pause()
                btnPlayPause.setImageResource(android.R.drawable.ic_media_play)
            } else {
                it.start()
                btnPlayPause.setImageResource(android.R.drawable.ic_media_pause)
            }
        }
    }

    private fun playNext() {
        if (displaySongsList.isNotEmpty()) {
            // Оптимізовано: перехід в межах відфільтрованого списку
            val currentIndex = displaySongsList.indexOfFirst { it.id == allSongsList[currentSongIndex].id }
            var nextIndex = currentIndex

            if (isShuffle) {
                nextIndex = Random.nextInt(displaySongsList.size)
            } else {
                nextIndex = (currentIndex + 1) % displaySongsList.size
            }

            val nextSong = displaySongsList[nextIndex]
            currentSongIndex = allSongsList.indexOf(nextSong) // Оновлюємо глобальний індекс
            playMusic(nextSong)
        }
    }

    private fun playPrev() {
        // Аналогічно для назад
        if (displaySongsList.isNotEmpty()) {
            val currentIndex = displaySongsList.indexOfFirst { it.id == allSongsList[currentSongIndex].id }
            var prevIndex = if (currentIndex > 0) currentIndex - 1 else displaySongsList.size - 1
            val prevSong = displaySongsList[prevIndex]
            currentSongIndex = allSongsList.indexOf(prevSong)
            playMusic(prevSong)
        }
    }

    private fun formatTime(millis: Int): String {
        val minutes = TimeUnit.MILLISECONDS.toMinutes(millis.toLong())
        val seconds = TimeUnit.MILLISECONDS.toSeconds(millis.toLong()) - TimeUnit.MINUTES.toSeconds(minutes)
        return String.format("%02d:%02d", minutes, seconds)
    }

    override fun onDestroy() {
        super.onDestroy()
        mediaPlayer?.release()
        handler.removeCallbacks(updateSeekBar)
    }
}
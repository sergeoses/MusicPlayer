package com.app.musicplayer

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

class SongsAdapter(
    private var songs: List<Song>,
    private val onSongClick: (Song) -> Unit,
    private val onSongLongClick: (Song) -> Unit
) : RecyclerView.Adapter<SongsAdapter.SongViewHolder>() {

    var selectedPosition = -1

    fun updateList(newSongs: List<Song>) {
        songs = newSongs
        notifyDataSetChanged()
    }

    class SongViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvTitle: TextView = view.findViewById(R.id.tvTitle)
        val tvArtist: TextView = view.findViewById(R.id.tvArtist)
        val tvFavIcon: TextView = view.findViewById(R.id.tvFavIcon)
        val iconContainer: View = view.findViewById(R.id.iconContainer)
        val tvIconText: TextView = view.findViewById(R.id.tvIconText)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
        return SongViewHolder(view)
    }

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.tvTitle.text = song.title
        holder.tvArtist.text = song.artist

        // Колір іконки
        val color = generateColor(song.title)
        // Створюємо круглий фон програмно, щоб не залежати від XML
        val shape = GradientDrawable()
        shape.shape = GradientDrawable.OVAL
        shape.setColor(color)
        holder.iconContainer.background = shape

        holder.tvIconText.text = if (song.title.isNotEmpty()) song.title.substring(0, 1).uppercase() else "♪"
        holder.tvFavIcon.visibility = if (song.isFavorite) View.VISIBLE else View.GONE

        // Підсвітка обраної пісні
        if (selectedPosition == position) {
            holder.tvTitle.setTextColor(Color.parseColor("#E94560"))
        } else {
            holder.tvTitle.setTextColor(Color.WHITE)
        }

        holder.itemView.setOnClickListener { onSongClick(song) }
        holder.itemView.setOnLongClickListener { onSongLongClick(song); true }
    }

    override fun getItemCount() = songs.size

    private fun generateColor(text: String): Int {
        val colors = arrayOf("#EF5350", "#EC407A", "#AB47BC", "#7E57C2", "#5C6BC0", "#42A5F5", "#29B6F6", "#26C6DA", "#26A69A", "#66BB6A", "#9CCC65", "#D4E157", "#FFCA28", "#FFA726")
        return Color.parseColor(colors[abs(text.hashCode()) % colors.size])
    }
}
package com.app.musicplayer

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val path: String,
    var isFavorite: Boolean = false
)